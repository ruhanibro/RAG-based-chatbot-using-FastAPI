from rest_framework import serializers
from .models import Document, DocumentChunk, QueryHistory
import base64
from django.core.files.base import ContentFile

class DocumentUploadSerializer(serializers.ModelSerializer):
    class Meta:
        model = Document
        fields = ['id', 'filename', 'file_type', 'file_path', 'file_size', 'uploaded_at', 'processed', 'total_chunks']
        read_only_fields = ['id', 'uploaded_at', 'processed', 'total_chunks']

class DocumentListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Document
        fields = ['id', 'filename', 'file_type', 'file_size', 'uploaded_at', 'processed', 'total_chunks']

class QueryRequestSerializer(serializers.Serializer):
    question = serializers.CharField(max_length=1000)
    image_base64 = serializers.CharField(required=False, allow_blank=True)
    document_ids = serializers.ListField(
        child=serializers.UUIDField(),
        required=False,
        allow_empty=True
    )
    
    def validate_image_base64(self, value):
        if value:
            try:
                # Validate base64 format
                base64.b64decode(value)
            except Exception:
                raise serializers.ValidationError("Invalid base64 image format")
        return value

class QueryResponseSerializer(serializers.Serializer):
    answer = serializers.CharField()
    context = serializers.CharField()
    sources = serializers.ListField(child=serializers.DictField())
    response_time = serializers.FloatField()
    query_id = serializers.UUIDField()

class QueryHistorySerializer(serializers.ModelSerializer):
    documents_referenced = DocumentListSerializer(many=True, read_only=True)
    
    class Meta:
        model = QueryHistory
        fields = ['id', 'question', 'answer', 'context_used', 'documents_referenced', 'response_time', 'created_at']