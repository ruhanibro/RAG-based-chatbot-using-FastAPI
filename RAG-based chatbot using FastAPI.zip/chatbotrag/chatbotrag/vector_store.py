import os
import pickle
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer
from typing import List, Dict, Any, Tuple
import logging
from django.conf import settings
from .models import Document, DocumentChunk

logger = logging.getLogger(__name__)

class VectorStoreManager:
    """Manages FAISS vector store for document embeddings"""
    
    def __init__(self):
        self.model = SentenceTransformer('all-MiniLM-L6-v2')
        self.dimension = 384  # Dimension for all-MiniLM-L6-v2
        self.vector_store_path = getattr(settings, 'VECTOR_STORE_PATH', 'vector_store')
        self.index_path = os.path.join(self.vector_store_path, 'faiss_index.bin')
        self.metadata_path = os.path.join(self.vector_store_path, 'metadata.pkl')
        
        # Create directory if it doesn't exist
        os.makedirs(self.vector_store_path, exist_ok=True)
        
        # Initialize or load index
        self.index = self._load_or_create_index()
        self.metadata = self._load_metadata()
    
    def _load_or_create_index(self) -> faiss.IndexFlatIP:
        """Load existing index or create new one"""
        if os.path.exists(self.index_path):
            try:
                index = faiss.read_index(self.index_path)
                logger.info(f"Loaded existing FAISS index with {index.ntotal} vectors")
                return index
            except Exception as e:
                logger.warning(f"Failed to load existing index: {str(e)}")
        
        # Create new index
        index = faiss.IndexFlatIP(self.dimension)  # Inner product for cosine similarity
        logger.info("Created new FAISS index")
        return index
    
    def _load_metadata(self) -> List[Dict[str, Any]]:
        """Load metadata for stored vectors"""
        if os.path.exists(self.metadata_path):
            try:
                with open(self.metadata_path, 'rb') as f:
                    metadata = pickle.load(f)
                logger.info(f"Loaded metadata for {len(metadata)} vectors")
                return metadata
            except Exception as e:
                logger.warning(f"Failed to load metadata: {str(e)}")
        
        return []
    
    def _save_index(self):
        """Save FAISS index to disk"""
        try:
            faiss.write_index(self.index, self.index_path)
            logger.info("Saved FAISS index")
        except Exception as e:
            logger.error(f"Failed to save index: {str(e)}")
    
    def _save_metadata(self):
        """Save metadata to disk"""
        try:
            with open(self.metadata_path, 'wb') as f:
                pickle.dump(self.metadata, f)
            logger.info("Saved metadata")
        except Exception as e:
            logger.error(f"Failed to save metadata: {str(e)}")
    
    def add_document_chunks(self, document: Document, chunks: List[DocumentChunk]):
        """Add document chunks to vector store"""
        if not chunks:
            return
        
        # Extract text content
        texts = [chunk.content for chunk in chunks]
        
        # Generate embeddings
        embeddings = self.model.encode(texts, convert_to_tensor=False)
        
        # Normalize embeddings for cosine similarity
        embeddings = embeddings / np.linalg.norm(embeddings, axis=1, keepdims=True)
        
        # Add to FAISS index
        self.index.add(embeddings.astype('float32'))
        
        # Add metadata
        for i, chunk in enumerate(chunks):
            metadata = {
                'document_id': str(document.id),
                'document_filename': document.filename,
                'chunk_id': chunk.id,
                'chunk_index': chunk.chunk_index,
                'page_number': chunk.page_number,
                'content': chunk.content,
                'chunk_metadata': chunk.chunk_metadata
            }
            self.metadata.append(metadata)
        
        # Save to disk
        self._save_index()
        self._save_metadata()
        
        logger.info(f"Added {len(chunks)} chunks from document {document.filename}")
    
    def search(self, query: str, k: int = 5, document_ids: List[str] = None) -> List[Dict[str, Any]]:
        """Search for similar chunks"""
        if self.index.ntotal == 0:
            return []
        
        # Generate query embedding
        query_embedding = self.model.encode([query], convert_to_tensor=False)
        query_embedding = query_embedding / np.linalg.norm(query_embedding, axis=1, keepdims=True)
        
        # Search in FAISS
        scores, indices = self.index.search(query_embedding.astype('float32'), min(k * 2, self.index.ntotal))
        
        # Filter results
        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx == -1:  # Invalid index
                continue
            
            metadata = self.metadata[idx]
            
            # Filter by document IDs if specified
            if document_ids and metadata['document_id'] not in document_ids:
                continue
            
            result = {
                'content': metadata['content'],
                'score': float(score),
                'document_id': metadata['document_id'],
                'document_filename': metadata['document_filename'],
                'chunk_index': metadata['chunk_index'],
                'page_number': metadata['page_number'],
                'metadata': metadata['chunk_metadata']
            }
            results.append(result)
            
            if len(results) >= k:
                break
        
        return results
    
    def remove_document(self, document_id: str):
        """Remove all chunks for a document from vector store"""
        # Find indices to remove
        indices_to_remove = []
        new_metadata = []
        
        for i, metadata in enumerate(self.metadata):
            if metadata['document_id'] == document_id:
                indices_to_remove.append(i)
            else:
                new_metadata.append(metadata)
        
        if not indices_to_remove:
            return
        
        # Rebuild index without removed vectors
        if len(new_metadata) > 0:
            # Get all remaining embeddings
            all_texts = [meta['content'] for meta in new_metadata]
            embeddings = self.model.encode(all_texts, convert_to_tensor=False)
            embeddings = embeddings / np.linalg.norm(embeddings, axis=1, keepdims=True)
            
            # Create new index
            new_index = faiss.IndexFlatIP(self.dimension)
            new_index.add(embeddings.astype('float32'))
            
            self.index = new_index
            self.metadata = new_metadata
        else:
            # Empty index
            self.index = faiss.IndexFlatIP(self.dimension)
            self.metadata = []
        
        # Save changes
        self._save_index()
        self._save_metadata()
        
        logger.info(f"Removed {len(indices_to_remove)} chunks for document {document_id}")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get vector store statistics"""
        return {
            'total_vectors': self.index.ntotal,
            'dimension': self.dimension,
            'total_documents': len(set(meta['document_id'] for meta in self.metadata)),
            'model_name': 'all-MiniLM-L6-v2'
        }