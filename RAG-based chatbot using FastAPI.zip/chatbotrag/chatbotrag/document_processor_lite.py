import os
import fitz  # PyMuPDF
import pdfplumber
from docx import Document as DocxDocument
import pytesseract
from PIL import Image
import pandas as pd
import sqlite3
from typing import List, Dict, Any
import logging
from django.conf import settings

logger = logging.getLogger(__name__)

class DocumentProcessorLite:
    """Lightweight document processor without heavy ML dependencies"""
    
    def __init__(self):
        self.chunk_size = getattr(settings, 'CHUNK_SIZE', 1000)
        self.chunk_overlap = getattr(settings, 'CHUNK_OVERLAP', 200)
    
    def process_document(self, file_path: str, file_type: str) -> List[Dict[str, Any]]:
        """Process document based on file type and return chunks"""
        try:
            if file_type.lower() == 'pdf':
                return self._process_pdf(file_path)
            elif file_type.lower() in ['docx', 'doc']:
                return self._process_docx(file_path)
            elif file_type.lower() == 'txt':
                return self._process_txt(file_path)
            elif file_type.lower() in ['jpg', 'jpeg', 'png', 'bmp', 'tiff']:
                return self._process_image(file_path)
            elif file_type.lower() == 'csv':
                return self._process_csv(file_path)
            elif file_type.lower() == 'db':
                return self._process_sqlite(file_path)
            else:
                raise ValueError(f"Unsupported file type: {file_type}")
        except Exception as e:
            logger.error(f"Error processing document {file_path}: {str(e)}")
            raise
    
    def _process_pdf(self, file_path: str) -> List[Dict[str, Any]]:
        """Process PDF files"""
        chunks = []
        
        # Try with PyMuPDF first
        try:
            doc = fitz.open(file_path)
            for page_num in range(len(doc)):
                page = doc.load_page(page_num)
                text = page.get_text()
                
                if text.strip():
                    page_chunks = self._create_text_chunks(text, page_num + 1)
                    chunks.extend(page_chunks)
                else:
                    # If no text, try OCR on the page
                    pix = page.get_pixmap()
                    img_data = pix.tobytes("png")
                    ocr_text = self._ocr_from_bytes(img_data)
                    if ocr_text.strip():
                        page_chunks = self._create_text_chunks(ocr_text, page_num + 1)
                        chunks.extend(page_chunks)
            doc.close()
        except Exception as e:
            logger.warning(f"PyMuPDF failed, trying pdfplumber: {str(e)}")
            # Fallback to pdfplumber
            with pdfplumber.open(file_path) as pdf:
                for page_num, page in enumerate(pdf.pages):
                    text = page.extract_text()
                    if text:
                        page_chunks = self._create_text_chunks(text, page_num + 1)
                        chunks.extend(page_chunks)
        
        return chunks
    
    def _process_docx(self, file_path: str) -> List[Dict[str, Any]]:
        """Process DOCX files"""
        doc = DocxDocument(file_path)
        full_text = []
        
        for paragraph in doc.paragraphs:
            if paragraph.text.strip():
                full_text.append(paragraph.text)
        
        text = '\n'.join(full_text)
        return self._create_text_chunks(text)
    
    def _process_txt(self, file_path: str) -> List[Dict[str, Any]]:
        """Process TXT files"""
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as file:
            text = file.read()
        return self._create_text_chunks(text)
    
    def _process_image(self, file_path: str) -> List[Dict[str, Any]]:
        """Process image files using OCR (pytesseract only)"""
        try:
            image = Image.open(file_path)
            text = pytesseract.image_to_string(image)
            return self._create_text_chunks(text)
        except Exception as e:
            logger.error(f"OCR failed for {file_path}: {str(e)}")
            return []
    
    def _process_csv(self, file_path: str) -> List[Dict[str, Any]]:
        """Process CSV files"""
        df = pd.read_csv(file_path)
        
        # Convert DataFrame to text representation
        text_parts = []
        text_parts.append(f"CSV file with {len(df)} rows and {len(df.columns)} columns")
        text_parts.append(f"Columns: {', '.join(df.columns.tolist())}")
        
        # Add sample data
        text_parts.append("\nSample data:")
        text_parts.append(df.head(10).to_string())
        
        # Add summary statistics for numeric columns
        numeric_cols = df.select_dtypes(include=['number']).columns
        if len(numeric_cols) > 0:
            text_parts.append("\nSummary statistics:")
            text_parts.append(df[numeric_cols].describe().to_string())
        
        text = '\n'.join(text_parts)
        return self._create_text_chunks(text)
    
    def _process_sqlite(self, file_path: str) -> List[Dict[str, Any]]:
        """Process SQLite database files"""
        conn = sqlite3.connect(file_path)
        cursor = conn.cursor()
        
        # Get table names
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = cursor.fetchall()
        
        text_parts = []
        text_parts.append(f"SQLite database with {len(tables)} tables")
        
        for table in tables:
            table_name = table[0]
            text_parts.append(f"\nTable: {table_name}")
            
            # Get table schema
            cursor.execute(f"PRAGMA table_info({table_name});")
            columns = cursor.fetchall()
            column_info = [f"{col[1]} ({col[2]})" for col in columns]
            text_parts.append(f"Columns: {', '.join(column_info)}")
            
            # Get sample data
            cursor.execute(f"SELECT * FROM {table_name} LIMIT 5;")
            rows = cursor.fetchall()
            if rows:
                text_parts.append("Sample data:")
                for row in rows:
                    text_parts.append(str(row))
        
        conn.close()
        text = '\n'.join(text_parts)
        return self._create_text_chunks(text)
    
    def _create_text_chunks(self, text: str, page_number: int = None) -> List[Dict[str, Any]]:
        """Create overlapping text chunks"""
        if not text.strip():
            return []
        
        chunks = []
        words = text.split()
        
        for i in range(0, len(words), self.chunk_size - self.chunk_overlap):
            chunk_words = words[i:i + self.chunk_size]
            chunk_text = ' '.join(chunk_words)
            
            chunk_data = {
                'content': chunk_text,
                'page_number': page_number,
                'word_count': len(chunk_words),
                'char_count': len(chunk_text)
            }
            chunks.append(chunk_data)
        
        return chunks
    
    def _ocr_from_bytes(self, image_bytes: bytes) -> str:
        """Perform OCR on image bytes using pytesseract only"""
        try:
            from io import BytesIO
            image = Image.open(BytesIO(image_bytes))
            return pytesseract.image_to_string(image)
        except Exception as e:
            logger.error(f"OCR failed: {str(e)}")
            return ""
    
    def process_image_base64(self, base64_string: str) -> str:
        """Process base64 encoded image for OCR"""
        import base64
        from io import BytesIO
        
        try:
            # Decode base64
            image_data = base64.b64decode(base64_string)
            image = Image.open(BytesIO(image_data))
            
            # Use pytesseract only
            text = pytesseract.image_to_string(image)
            return text
        except Exception as e:
            logger.error(f"Error processing base64 image: {str(e)}")
            return ""