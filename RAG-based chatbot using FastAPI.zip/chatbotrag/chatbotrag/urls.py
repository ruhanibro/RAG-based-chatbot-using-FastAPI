from django.urls import path
from . import views

urlpatterns = [
    # Document management
    path('upload/', views.upload_document, name='upload_document'),
    path('documents/', views.list_documents, name='list_documents'),
    path('documents/<uuid:document_id>/', views.delete_document, name='delete_document'),
    
    # Query endpoints
    path('query/', views.query_documents, name='query_documents'),
    path('history/', views.query_history, name='query_history'),
    
    # System endpoints
    path('stats/', views.vector_store_stats, name='vector_store_stats'),
    path('health/', views.health_check, name='health_check'),
]