"""
Suppress various warnings and deprecation messages
"""
import os
import warnings
import logging

# Suppress all warnings
warnings.filterwarnings('ignore')

# Set environment variables to suppress TensorFlow warnings
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
os.environ['TF_DISABLE_DEPRECATION_WARNINGS'] = '1'
os.environ['HF_HUB_DISABLE_SYMLINKS_WARNING'] = '1'

# Suppress specific TensorFlow warnings (only if TensorFlow is available)
try:
    import tensorflow as tf
    tf.get_logger().setLevel('ERROR')
    tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)
except ImportError:
    pass

# Suppress protobuf warnings
logging.getLogger('protobuf').setLevel(logging.ERROR)

# Suppress transformers warnings
logging.getLogger('transformers').setLevel(logging.ERROR)

# Suppress sentence-transformers warnings
logging.getLogger('sentence_transformers').setLevel(logging.ERROR)

# Suppress other common warnings
logging.getLogger('urllib3').setLevel(logging.ERROR)
logging.getLogger('requests').setLevel(logging.ERROR)