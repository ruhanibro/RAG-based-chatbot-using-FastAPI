from django.db import models
from django.contrib.auth.models import User
import uuid

class Document(models.Model):
    """Model to store uploaded documents"""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    filename = models.CharField(max_length=255)
    file_type = models.CharField(max_length=50)
    file_path = models.FileField(upload_to='documents/')
    file_size = models.IntegerField()
    uploaded_at = models.DateTimeField(auto_now_add=True)
    processed = models.BooleanField(default=False)
    total_chunks = models.IntegerField(default=0)
    
    def __str__(self):
        return f"{self.filename} ({self.file_type})"

class DocumentChunk(models.Model):
    """Model to store document chunks with metadata"""
    document = models.ForeignKey(Document, on_delete=models.CASCADE, related_name='chunks')
    chunk_index = models.IntegerField()
    content = models.TextField()
    page_number = models.IntegerField(null=True, blank=True)
    chunk_metadata = models.JSONField(default=dict)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['document', 'chunk_index']
    
    def __str__(self):
        return f"{self.document.filename} - Chunk {self.chunk_index}"

class QueryHistory(models.Model):
    """Model to store query history"""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    question = models.TextField()
    answer = models.TextField()
    context_used = models.TextField()
    documents_referenced = models.ManyToManyField(Document, blank=True)
    response_time = models.FloatField()
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Query: {self.question[:50]}..."