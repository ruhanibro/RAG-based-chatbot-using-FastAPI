from django.contrib import admin
from .models import Document, DocumentChunk, QueryHistory

@admin.register(Document)
class DocumentAdmin(admin.ModelAdmin):
    list_display = ['filename', 'file_type', 'file_size', 'processed', 'total_chunks', 'uploaded_at']
    list_filter = ['file_type', 'processed', 'uploaded_at']
    search_fields = ['filename']
    readonly_fields = ['id', 'uploaded_at', 'file_size']
    
    def get_queryset(self, request):
        return super().get_queryset(request).prefetch_related('chunks')

@admin.register(DocumentChunk)
class DocumentChunkAdmin(admin.ModelAdmin):
    list_display = ['document', 'chunk_index', 'page_number', 'content_preview', 'created_at']
    list_filter = ['document__file_type', 'page_number', 'created_at']
    search_fields = ['content', 'document__filename']
    readonly_fields = ['created_at']
    
    def content_preview(self, obj):
        return obj.content[:100] + "..." if len(obj.content) > 100 else obj.content
    content_preview.short_description = "Content Preview"

@admin.register(QueryHistory)
class QueryHistoryAdmin(admin.ModelAdmin):
    list_display = ['question_preview', 'response_time', 'created_at']
    list_filter = ['created_at']
    search_fields = ['question', 'answer']
    readonly_fields = ['id', 'created_at', 'response_time']
    filter_horizontal = ['documents_referenced']
    
    def question_preview(self, obj):
        return obj.question[:50] + "..." if len(obj.question) > 50 else obj.question
    question_preview.short_description = "Question"