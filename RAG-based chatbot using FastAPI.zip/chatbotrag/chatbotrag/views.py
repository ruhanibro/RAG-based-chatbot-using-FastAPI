import os
import time
import logging
from typing import List, Dict, Any
from django.http import JsonResponse
from django.conf import settings
from rest_framework import status
from rest_framework.decorators import api_view, parser_classes
from rest_framework.parsers import MultiPartParser, JSONParser
from rest_framework.response import Response
from .models import Document, DocumentChunk, QueryHistory
from .serializers import (
    DocumentUploadSerializer, DocumentListSerializer,
    QueryRequestSerializer, QueryResponseSerializer, QueryHistorySerializer
)
from .document_processor_lite import DocumentProcessorLite as DocumentProcessor
from .vector_store import VectorStoreManager
from .llm_client import LLMClient

logger = logging.getLogger(__name__)

# Initialize components
document_processor = DocumentProcessor()
vector_store = VectorStoreManager()
llm_client = LLMClient()

@api_view(['POST'])
@parser_classes([MultiPartParser])
def upload_document(request):
    """Upload and process a document"""
    try:
        # Debug logging
        logger.info(f"Upload request received. Method: {request.method}")
        logger.info(f"Content type: {request.content_type}")
        logger.info(f"FILES keys: {list(request.FILES.keys())}")
        logger.info(f"POST keys: {list(request.POST.keys())}")
        
        if 'file' not in request.FILES:
            return Response(
                {'error': 'No file provided', 'debug': {
                    'files_keys': list(request.FILES.keys()),
                    'post_keys': list(request.POST.keys()),
                    'content_type': request.content_type
                }}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        uploaded_file = request.FILES['file']
        file_extension = os.path.splitext(uploaded_file.name)[1][1:].lower()
        
        # Create document record
        document = Document.objects.create(
            filename=uploaded_file.name,
            file_type=file_extension,
            file_path=uploaded_file,
            file_size=uploaded_file.size
        )
        
        # Process document in background (for production, use Celery)
        try:
            file_path = document.file_path.path
            chunks_data = document_processor.process_document(file_path, file_extension)
            
            # Create document chunks
            chunks = []
            for i, chunk_data in enumerate(chunks_data):
                chunk = DocumentChunk.objects.create(
                    document=document,
                    chunk_index=i,
                    content=chunk_data['content'],
                    page_number=chunk_data.get('page_number'),
                    chunk_metadata=chunk_data
                )
                chunks.append(chunk)
            
            # Add to vector store
            vector_store.add_document_chunks(document, chunks)
            
            # Update document status
            document.processed = True
            document.total_chunks = len(chunks)
            document.save()
            
            logger.info(f"Successfully processed document {document.filename} with {len(chunks)} chunks")
            
        except Exception as e:
            logger.error(f"Error processing document {document.filename}: {str(e)}")
            document.delete()  # Clean up failed upload
            return Response(
                {'error': f'Failed to process document: {str(e)}'}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        
        serializer = DocumentUploadSerializer(document)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
        
    except Exception as e:
        logger.error(f"Error in upload_document: {str(e)}")
        return Response(
            {'error': str(e)}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@api_view(['GET'])
def list_documents(request):
    """List all uploaded documents"""
    try:
        documents = Document.objects.all().order_by('-uploaded_at')
        serializer = DocumentListSerializer(documents, many=True)
        return Response(serializer.data)
    except Exception as e:
        logger.error(f"Error in list_documents: {str(e)}")
        return Response(
            {'error': str(e)}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@api_view(['DELETE'])
def delete_document(request, document_id):
    """Delete a document and its chunks"""
    try:
        document = Document.objects.get(id=document_id)
        
        # Remove from vector store
        vector_store.remove_document(str(document.id))
        
        # Delete file
        if document.file_path and os.path.exists(document.file_path.path):
            os.remove(document.file_path.path)
        
        # Delete from database
        document.delete()
        
        return Response({'message': 'Document deleted successfully'})
        
    except Document.DoesNotExist:
        return Response(
            {'error': 'Document not found'}, 
            status=status.HTTP_404_NOT_FOUND
        )
    except Exception as e:
        logger.error(f"Error in delete_document: {str(e)}")
        return Response(
            {'error': str(e)}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@api_view(['POST'])
@parser_classes([JSONParser])
def query_documents(request):
    """Query documents using RAG"""
    start_time = time.time()
    
    try:
        # Validate request
        serializer = QueryRequestSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        question = serializer.validated_data['question']
        image_base64 = serializer.validated_data.get('image_base64')
        document_ids = serializer.validated_data.get('document_ids', [])
        
        # Check if API key is configured
        if not llm_client.check_api_key():
            return Response(
                {'error': 'LLM API key not configured. Please set either OPENROUTER_API_KEY or OPENAI_API_KEY environment variable.'}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        
        # Process image if provided
        image_text = ""
        if image_base64:
            image_text = document_processor.process_image_base64(image_base64)
            logger.info(f"Extracted text from image: {len(image_text)} characters")
        
        # Search vector store
        search_results = vector_store.search(
            query=question, 
            k=5, 
            document_ids=[str(doc_id) for doc_id in document_ids] if document_ids else None
        )
        
        if not search_results:
            return Response({
                'answer': 'I could not find any relevant information in the uploaded documents to answer your question.',
                'context': '',
                'sources': [],
                'response_time': time.time() - start_time,
                'query_id': None
            })
        
        # Construct context
        context_parts = []
        sources = []
        
        for i, result in enumerate(search_results):
            context_parts.append(f"[Source {i+1}] {result['content']}")
            sources.append({
                'document_filename': result['document_filename'],
                'page_number': result['page_number'],
                'chunk_index': result['chunk_index'],
                'similarity_score': result['score']
            })
        
        context = '\n\n'.join(context_parts)
        
        # Generate answer using LLM
        if image_base64 and 'gpt-4' in llm_client.model:
            # Use multimodal capabilities if available
            answer = llm_client.generate_multimodal_answer(question, context, image_base64)
        else:
            # Standard text-based generation
            answer = llm_client.generate_answer(question, context, image_text)
        
        response_time = time.time() - start_time
        
        # Save query history
        query_history = QueryHistory.objects.create(
            question=question,
            answer=answer,
            context_used=context,
            response_time=response_time
        )
        
        # Add referenced documents
        referenced_doc_ids = list(set(result['document_id'] for result in search_results))
        referenced_docs = Document.objects.filter(id__in=referenced_doc_ids)
        query_history.documents_referenced.set(referenced_docs)
        
        response_data = {
            'answer': answer,
            'context': context,
            'sources': sources,
            'response_time': response_time,
            'query_id': query_history.id
        }
        
        return Response(response_data)
        
    except Exception as e:
        logger.error(f"Error in query_documents: {str(e)}")
        return Response(
            {'error': str(e)}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@api_view(['GET'])
def query_history(request):
    """Get query history"""
    try:
        queries = QueryHistory.objects.all().order_by('-created_at')[:50]  # Last 50 queries
        serializer = QueryHistorySerializer(queries, many=True)
        return Response(serializer.data)
    except Exception as e:
        logger.error(f"Error in query_history: {str(e)}")
        return Response(
            {'error': str(e)}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@api_view(['GET'])
def vector_store_stats(request):
    """Get vector store statistics"""
    try:
        stats = vector_store.get_stats()
        return Response(stats)
    except Exception as e:
        logger.error(f"Error in vector_store_stats: {str(e)}")
        return Response(
            {'error': str(e)}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@api_view(['GET'])
def health_check(request):
    """Health check endpoint"""
    try:
        return Response({
            'status': 'healthy',
            'llm_configured': llm_client.check_api_key(),
            'llm_provider': getattr(llm_client, 'provider', 'unknown'),
            'llm_model': getattr(llm_client, 'model', 'unknown'),
            'vector_store_stats': vector_store.get_stats(),
            'total_documents': Document.objects.count()
        })
    except Exception as e:
        logger.error(f"Error in health_check: {str(e)}")
        return Response(
            {'error': str(e)}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )