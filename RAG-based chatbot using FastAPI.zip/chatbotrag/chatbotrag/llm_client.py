import os
from openai import OpenAI
from typing import List, Dict, Any
import logging
from django.conf import settings

logger = logging.getLogger(__name__)

class LLMClient:
    """Client for interacting with LLM APIs (OpenRouter or OpenAI)"""
    
    def __init__(self):
        self.max_tokens = int(os.getenv('MAX_TOKENS', '1000'))
        self.temperature = float(os.getenv('TEMPERATURE', '0.1'))
        
        # Check for OpenRouter configuration first
        if os.getenv('OPENROUTER_API_KEY'):
            try:
                self.client = OpenAI(
                    api_key=os.getenv('OPENROUTER_API_KEY'),
                    base_url=os.getenv('OPENROUTER_BASE_URL', 'https://openrouter.ai/api/v1')
                )
                self.model = os.getenv('OPENROUTER_MODEL', 'openai/gpt-3.5-turbo')
                self.provider = 'openrouter'
                logger.info(f"Using OpenRouter with model: {self.model}")
            except Exception as e:
                logger.error(f"Failed to initialize OpenRouter client: {str(e)}")
                self.client = None
                self.provider = 'none'
        elif os.getenv('OPENAI_API_KEY'):
            try:
                self.client = OpenAI(
                    api_key=os.getenv('OPENAI_API_KEY')
                )
                self.model = os.getenv('OPENAI_MODEL', 'gpt-3.5-turbo')
                self.provider = 'openai'
                logger.info(f"Using OpenAI with model: {self.model}")
            except Exception as e:
                logger.error(f"Failed to initialize OpenAI client: {str(e)}")
                self.client = None
                self.provider = 'none'
        else:
            logger.warning("No API key found. LLM client will not be functional.")
            self.client = None
            self.provider = 'none'
            self.model = 'none'
    
    def generate_answer(self, question: str, context: str, image_text: str = None) -> str:
        """Generate answer using LLM with RAG context"""
        
        if self.client is None:
            return "LLM client is not properly configured. Please check your API key settings."
        
        # Construct the prompt
        system_prompt = """You are a helpful AI assistant that answers questions based on the provided context. 
        Follow these guidelines:
        1. Answer based primarily on the provided context
        2. If the context doesn't contain enough information, say so clearly
        3. Be concise but comprehensive
        4. Cite specific parts of the context when relevant
        5. If image text is provided, incorporate it into your analysis"""
        
        user_prompt = f"""Context from documents:
{context}

"""
        
        if image_text:
            user_prompt += f"""Additional context from image:
{image_text}

"""
        
        user_prompt += f"""Question: {question}

Please provide a detailed answer based on the context above."""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                max_tokens=self.max_tokens,
                temperature=self.temperature
            )
            
            return response.choices[0].message.content.strip()
            
        except Exception as e:
            logger.error(f"Error generating answer: {str(e)}")
            return f"I apologize, but I encountered an error while generating the answer: {str(e)}"
    
    def generate_multimodal_answer(self, question: str, context: str, image_base64: str) -> str:
        """Generate answer using GPT-4 Vision for multimodal input"""
        
        system_prompt = """You are a helpful AI assistant that can analyze both text and images. 
        Answer questions based on the provided text context and image content."""
        
        user_prompt = f"""Text context from documents:
{context}

Question: {question}

Please analyze both the text context and the image to provide a comprehensive answer."""
        
        # Choose appropriate vision model based on provider
        if self.provider == 'openrouter':
            vision_model = "openai/gpt-4-vision-preview"
        else:
            vision_model = "gpt-4-vision-preview"
        
        try:
            response = self.client.chat.completions.create(
                model=vision_model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": user_prompt},
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:image/jpeg;base64,{image_base64}"
                                }
                            }
                        ]
                    }
                ],
                max_tokens=self.max_tokens,
                temperature=self.temperature
            )
            
            return response.choices[0].message.content.strip()
            
        except Exception as e:
            logger.error(f"Error generating multimodal answer: {str(e)}")
            # Fallback to text-only processing
            return self.generate_answer(question, context)
    
    def check_api_key(self) -> bool:
        """Check if API key is configured and client is initialized"""
        return self.client is not None and bool(os.getenv('OPENROUTER_API_KEY') or os.getenv('OPENAI_API_KEY'))
    
    def get_available_models(self) -> List[str]:
        """Get list of available models"""
        try:
            models = self.client.models.list()
            return [model.id for model in models.data if 'gpt' in model.id]
        except Exception as e:
            logger.error(f"Error fetching models: {str(e)}")
            return ['gpt-3.5-turbo', 'gpt-4']