# Smart RAG Chatbot API

A powerful Retrieval-Augmented Generation (RAG) API built with Django that can answer questions based on information extracted from various document types including PDFs, Word files, images (OCR), text files, and databases.

## Features

### Document Processing
- **PDF Files**: Extract text using PyMuPDF and pdfplumber, with OCR fallback for scanned documents
- **Word Documents**: Process .docx files using python-docx
- **Text Files**: Direct text processing
- **Images**: OCR using both EasyOCR and pytesseract for maximum accuracy
- **CSV Files**: Convert tabular data to searchable text with statistics
- **SQLite Databases**: Extract schema and sample data for querying

### Advanced Capabilities
- **Vector Search**: FAISS-powered similarity search with sentence transformers
- **Multimodal Support**: Handle both text and image-based questions
- **Smart Chunking**: Overlapping text chunks for better context preservation
- **Query History**: Track and analyze previous queries
- **Document Management**: Upload, list, and delete documents via API

## Installation

### Prerequisites
- Python 3.8+
- pip or conda
- Tesseract OCR (for image processing)

### Setup

1. **Clone and navigate to the project**:
```bash
cd chatbotrag
```

2. **Create virtual environment**:
```bash
python -m venv venv
# Windows
venv\Scripts\activate
# Linux/Mac
source venv/bin/activate
```

3. **Install dependencies**:
```bash
pip install -r requirements.txt
```

4. **Install Tesseract OCR**:
   - **Windows**: Download from https://github.com/UB-Mannheim/tesseract/wiki
   - **Ubuntu**: `sudo apt-get install tesseract-ocr`
   - **macOS**: `brew install tesseract`

5. **Environment Configuration**:
```bash
cp .env.example .env
# Edit .env with your OpenAI API key and other settings
```

6. **Database Setup**:
```bash
python manage.py makemigrations
python manage.py migrate
```

7. **Create Superuser** (optional):
```bash
python manage.py createsuperuser
```

8. **Run the Server**:
```bash
python manage.py runserver
```

The API will be available at `http://localhost:8000/api/`

## API Usage

### 1. Upload Document
```bash
curl -X POST http://localhost:8000/api/upload/ \
  -F "file=@document.pdf"
```

**Response**:
```json
{
  "id": "uuid-here",
  "filename": "document.pdf",
  "file_type": "pdf",
  "file_size": 1024000,
  "uploaded_at": "2024-01-01T12:00:00Z",
  "processed": true,
  "total_chunks": 25
}
```

### 2. Query Documents
```bash
curl -X POST http://localhost:8000/api/query/ \
  -H "Content-Type: application/json" \
  -d '{
    "question": "What are the main findings in the research paper?",
    "document_ids": ["uuid-here"]
  }'
```

**Response**:
```json
{
  "answer": "Based on the research paper, the main findings are...",
  "context": "Relevant context from documents...",
  "sources": [
    {
      "document_filename": "research.pdf",
      "page_number": 3,
      "chunk_index": 5,
      "similarity_score": 0.85
    }
  ],
  "response_time": 2.34,
  "query_id": "query-uuid"
}
```

### 3. Query with Image
```bash
curl -X POST http://localhost:8000/api/query/ \
  -H "Content-Type: application/json" \
  -d '{
    "question": "What does this diagram show?",
    "image_base64": "base64-encoded-image-data"
  }'
```

### 4. List Documents
```bash
curl http://localhost:8000/api/documents/
```

### 5. Delete Document
```bash
curl -X DELETE http://localhost:8000/api/documents/uuid-here/
```

### 6. Query History
```bash
curl http://localhost:8000/api/history/
```

### 7. System Health Check
```bash
curl http://localhost:8000/api/health/
```

## Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `OPENAI_API_KEY` | OpenAI API key (required) | - |
| `OPENAI_MODEL` | OpenAI model to use | `gpt-3.5-turbo` |
| `MAX_TOKENS` | Maximum tokens for LLM response | `1000` |
| `TEMPERATURE` | LLM temperature (0-1) | `0.1` |
| `CHUNK_SIZE` | Text chunk size for processing | `1000` |
| `CHUNK_OVERLAP` | Overlap between chunks | `200` |

### Supported File Types

| Type | Extensions | Processing Method |
|------|------------|-------------------|
| PDF | `.pdf` | PyMuPDF + OCR fallback |
| Word | `.docx`, `.doc` | python-docx |
| Text | `.txt` | Direct reading |
| Images | `.jpg`, `.jpeg`, `.png`, `.bmp`, `.tiff` | EasyOCR + pytesseract |
| CSV | `.csv` | pandas with statistics |
| Database | `.db` | SQLite schema + sample data |

## Architecture

### Components

1. **Document Processor** (`document_processor.py`):
   - Handles different file types
   - Extracts and chunks text content
   - Performs OCR on images

2. **Vector Store Manager** (`vector_store.py`):
   - FAISS-based vector storage
   - Sentence transformer embeddings
   - Similarity search functionality

3. **LLM Client** (`llm_client.py`):
   - OpenAI API integration
   - Multimodal support (GPT-4 Vision)
   - Context-aware answer generation

4. **Django Models**:
   - `Document`: Store document metadata
   - `DocumentChunk`: Store processed text chunks
   - `QueryHistory`: Track query history

### Data Flow

1. **Document Upload** → Processing → Chunking → Embedding → Vector Store
2. **Query** → Vector Search → Context Retrieval → LLM Generation → Response

## Sample Files

Create a `sample_files` directory with test documents:

```
sample_files/
├── sample.pdf          # Research paper or report
├── sample.docx         # Word document
├── sample.txt          # Plain text file
├── sample.jpg          # Image with text
├── sample.csv          # Data file
└── sample.db           # SQLite database
```

## Testing

### Basic Test
```bash
# Upload a document
curl -X POST http://localhost:8000/api/upload/ -F "file=@sample.pdf"

# Query the document
curl -X POST http://localhost:8000/api/query/ \
  -H "Content-Type: application/json" \
  -d '{"question": "What is this document about?"}'
```

### Image OCR Test
```bash
# Convert image to base64
base64 sample.jpg > image_b64.txt

# Query with image
curl -X POST http://localhost:8000/api/query/ \
  -H "Content-Type: application/json" \
  -d "{\"question\": \"What text is in this image?\", \"image_base64\": \"$(cat image_b64.txt)\"}"
```

## Deployment

### Docker (Optional)
```dockerfile
FROM python:3.9-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

# Install Tesseract
RUN apt-get update && apt-get install -y tesseract-ocr

COPY . .
EXPOSE 8000

CMD ["python", "manage.py", "runserver", "0.0.0.0:8000"]
```

### Production Considerations
- Use PostgreSQL instead of SQLite
- Set up Redis for caching
- Use Celery for background document processing
- Configure proper logging
- Set up monitoring and health checks
- Use environment-specific settings

## Troubleshooting

### Common Issues

1. **Tesseract not found**:
   - Ensure Tesseract is installed and in PATH
   - On Windows, add Tesseract to system PATH

2. **OpenAI API errors**:
   - Verify API key is correct
   - Check API quota and billing
   - Ensure model name is valid

3. **Memory issues with large files**:
   - Increase Django file upload limits
   - Consider chunking large documents
   - Use streaming for very large files

4. **Vector store corruption**:
   - Delete `vector_store/` directory to reset
   - Re-upload documents to rebuild index

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## License

MIT License - see LICENSE file for details.

## Support

For issues and questions:
- Check the troubleshooting section
- Review the API documentation
- Open an issue on GitHub